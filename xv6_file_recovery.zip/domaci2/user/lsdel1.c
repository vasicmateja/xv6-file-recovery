#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"
#include "kernel/fs.h"

char*
fmtname(char *path)
{
	static char buf[DIRSIZ+1];
	char *p;

	// Find first character after last slash.
	for(p=path+strlen(path); p >= path && *p != '/'; p--)
		;
	p++;

	// Return blank-padded name.
	if(strlen(p) >= DIRSIZ)
		return p;
	memmove(buf, p, strlen(p));
	memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
	return buf;
}


void
lsdel2(char *path)
{
	char buf[512];
	int fd;
	struct dirent de;
	struct stat st;

	if((fd = open(path, 0)) < 0){
		fprintf(2, "proveriti unetu putanju, ova nije dobra");
		//fprintf(2, "ls: cannot open %s\n", path);
		return;
	}

	if(fstat(fd, &st) < 0){
		fprintf(2, "ls: cannot stat %s\n", path);
		close(fd);
		return;
	}
	char result[300]="";
	//char result[64][DIRSIZ+1];
			
	if (lsdel1(path,result)==-1)
		close(fd);

	if(result != ""){
		fprintf(2, "%s\n", result);
	}else{
		fprintf(2,"Nema obrisanih fajlova");
	}
	/*
	//fprintf(2, "%s\n", result);
	
	
	for(int k = 0; k <i; k++){
		int j = 0;
		while(result[k][j] != 0){
			fprintf(2, "%c", result[k][j]);
			j++;
		}
		fprintf(2, "\n");
	}
	*/
	close(fd);
}

int
main(int argc, char *argv[])
{
	int i;

	if(argc < 2){
		lsdel2(".");
		exit();
	}
	for(i=1; i<argc; i++)
		lsdel2(argv[i]);
	exit();
}
